Date.prototype.yyyymmdd = function () {
  var mm = this.getMonth() + 1; // getMonth() is zero-based
  var dd = this.getDate();

  return [
    this.getFullYear(),
    (mm > 9 ? "" : "0") + mm,
    (dd > 9 ? "" : "0") + dd,
  ].join("-");
};

export const START_DATE_GLOBAL = "2000-01-01";
var currentTime = new Date();
export const END_DATE_GLOBAL = currentTime.yyyymmdd();
