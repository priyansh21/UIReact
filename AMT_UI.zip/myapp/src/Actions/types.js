export const SIGN_IN = "SIGN_IN";
export const SIGN_OUT = "SIGN_OUT";
export const GET_TC = "GET_TC";
export const GET_TEST_EXECUTION = "GET_TEST_EXECUTION";
export const GET_TEST_RUN = "GET_TEST_RUN";
export const FREE_SLOT = "FREE_SLOT";
