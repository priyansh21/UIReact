import history from "../history";
import amt from "../apis/amt";
import {
  SIGN_IN,
  SIGN_OUT,
  GET_TC,
  GET_TEST_EXECUTION,
  GET_TEST_RUN,
  FREE_SLOT,
} from "./types";
import { START_DATE_GLOBAL, END_DATE_GLOBAL } from "./dates";
import meetings from "../apis/meetings";

export const signIn = ({ username, password }) => async (dispatch) => {
  const headers = { Authorization: "Basic " + btoa(`${username}:${password}`) };

  const response = await amt.get("/api/3.0.4/auth/", {
    headers: headers,
  });
  dispatch({ type: SIGN_IN, payload: response.data });
  if (response.status === 200) {
    localStorage.setItem("token", "true");
    localStorage.setItem("userid", response.data);
    history.push("/AutoMaTics/index");
  } else {
    history.push("/");
  }
};

export const signOut = () => {
  localStorage.removeItem("userid");
  localStorage.removeItem("token");

  return {
    type: SIGN_OUT,
  };
};

export const getTc = (username, password) => {
  return async (dispatch) => {
    const headers = {
      Authorization: "Basic " + btoa(`${username}:${password}`),
    };

    const response = await amt.get("/api/testcases", {
      headers: headers,
    });
    dispatch({ type: GET_TC, payload: response.data });
  };
};

export const getReport = (username, password) => async (dispatch) => {
  const headers = { Authorization: "Basic " + btoa(`${username}:${password}`) };
  const response = await amt.get(
    `/api/chart/execution/${START_DATE_GLOBAL}/${END_DATE_GLOBAL}/All`,
    {
      headers: headers,
    }
  );

  dispatch({ type: GET_TEST_EXECUTION, payload: response });
};

export const getTestRun = (username, password) => async (dispatch) => {
  const headers = { Authorization: "Basic " + btoa(`${username}:${password}`) };
  const response = await amt.get(
    "http://localhost:3001/api//testruns/web_api_automation(Iteration%201)--2020-09-18_13:55:32",
    {
      headers: headers,
    }
  );

  dispatch({ type: GET_TEST_RUN, payload: response });
};

export const booking = () => {
  return async (dispatch) => {
    let response = await meetings.get("freeslots/12/22");
    console.log("inside booking action", response);
    dispatch({ type: FREE_SLOT, payload: response });
  };
};
