import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { createStore, applyMiddleware, compose } from "redux";
import reduxThunk from "redux-thunk";
import history from "./history";
import App from "./Components/App";
import reducers from "./Reducers";
import { Router, Route, Switch } from "react-router-dom";
// import { connect } from "react-redux";
import Booking from "./Components/Booking";
import LoadingPage from "./Components/LoadingPage";
import Login from "./Components/Login";
// import ContextMenu from "./Components/ContextMenu";
import Home from "./Components/Home";
import SignOut from "./Components/SignOut";
import Report from "./Components/Report";
// import Pagination from "./Components/Pagination";

const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const store = createStore(
  reducers,
  {
    auth: {
      isSignedIn: localStorage.getItem("token"),
      userid: localStorage.getItem("userid"),
    },
  },
  composeEnhancers(applyMiddleware(reduxThunk))
);
ReactDOM.render(
  <Provider store={store}>
    <Router history={history}>
      <App>
        <Switch>
          <Route path="/" exact component={Home} />
          <Route path="/signin" exact component={Login} />
          <Route path="/signout" exact component={SignOut} />
          <Route path="/AutoMaTics/index" exact component={LoadingPage} />
          <Route path="/AutoMaTics/report" exact component={Report} />
          <Route path="/booking" exact component={Booking} />
          <Route
            path="*"
            component={() => {
              return <div>404 not found</div>;
            }}
          />
        </Switch>
      </App>
    </Router>
  </Provider>,
  document.querySelector("#root")
);
