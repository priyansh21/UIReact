import { connect } from "react-redux";
import React, { Component } from "react";
import { getTestRun } from "../Actions";
import Spinner from "./Loader";
import Modal from "./Modal";
import { Link } from "react-router-dom";
import history from "../history";

class Report extends Component {

  constructor(props) {
    super(props);
    this.state = { showModal: false, content: null };

    this.handleShow = this.handleShow.bind(this);
    this.handleHide = this.handleHide.bind(this);
  }

  handleShow(content) {
    this.setState({ showModal: true, content });
  }

  handleHide() {
    this.setState({ showModal: false });
  }

  componentDidMount() {
    console.log(this.props);
    this.props.getTestRun("ps00503946", "Testing123");
  }

  renderActions() {
    // const { id } = this.props.match.params;
    return (
      <React.Fragment>
        <button
          // onClick={() => this.props.deleteStream(id)}
          className="ui  button negative"
        >
          Delete
        </button>
        <button
          onClick={this.handleHide}
          className="ui cancel button"
        >
          Cancel
        </button>
        {/* <Link to="/AutoMaTics/report" className="ui cancel button">
          Cancel
        </Link> */}
      </React.Fragment>
    );
  }

  renderContent = () => {
    console.log(typeof this.state.content);
    return this.state.content;
  };

  renderTable() {
    if (this.props.TestRun.data === undefined) return <Spinner />;

    // console.log();
    return (
      <div>
        <table className="ui celled table">
          <thead>
            <tr>
              <th>Step No.</th>
              <th>Step Timer</th>
              <th>Step description</th>
              <th>Step EXP</th>
              <th>Step Actual</th>
              <th>Status</th>
              <th>Screenshot</th>
            </tr>
          </thead>
          <tbody>
            {this.props.TestRun.data.steps.map((testStep) => {
              return (
                <tr key={testStep.stepNum}>
                  <td data-label="Step No.">{testStep.stepNum}</td>
                  <td data-label="Step Timer">{testStep.stepTimer}</td>
                  <td data-label="Step description">{testStep.stepDesc}</td>
                  <td data-label="Step EXP">{testStep.stepExp}</td>
                  <td data-label="Step Actual">{testStep.stepActual}</td>
                  <td data-label="Status">{testStep.stepStatus}</td>
                  <td
                    data-label="Screenshot"

                  >
                    {testStep.stepScreenshot ? <div key={testStep.stepNum} onClick={(e) => this.handleShow(e.target)} dangerouslySetInnerHTML={{ __html: testStep.stepScreenshot }} /> : ""}

                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
    // console.log(this.props.TestRun);
    // return <div>dd</div>;
  }
  render() {

    const modal = this.state.showModal ? <Modal
      header="Delete Stream"
      content={this.renderContent()}
      actions={this.renderActions()}
      onDismiss={() => this.handleHide()}
    /> : null;







    if (this.props.TestRun === undefined) {
      return <div>loadiing</div>;
    }

    return (<div>{this.renderTable()}
      {modal}
    </div>);
  }
}

const mapStateToProps = (state) => {
  return { TestRun: state.TestRunData };
};

export default connect(mapStateToProps, { getTestRun: getTestRun })(Report);
