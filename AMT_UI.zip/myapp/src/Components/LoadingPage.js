import React from "react";
import { connect } from "react-redux";
import { getTc } from "../Actions";
// import ContextMenu from "../Components/ContextMenu";
import requireAuth from "./requireAuth";

class LoadingPage extends React.Component {
  componentDidMount() {
    this.props.getTc("ps00503946", "Testing123");
  }

  renderTable = () => {
    if (this.props.tc === null) {
      return;
    }

    return this.props.tc.map((each) => {
      return (
        <tr key={each.tcName}>
          <th>{each.tcName}</th>
          <th>{each.tcType}</th>
          <th>{each.projectName}</th>
        </tr>
      );
    });
  };

  render() {
    if (this.props.tc != null) {
      // console.log(this.props.tc);
    }
    // console.log(this.props);
    return (
      <table
        className="ui celled table"
        // onContextMenu={(event) => {
        //   event.preventDefault();
        //   const xPos = event.pageX + "px";
        //   const yPos = event.pageY + "px";
        //   console.log("right click");
        // <ContextMenu style={{ top: xPos, left: yPos }} />;
        // }
        // }
      >
        <thead>
          <tr>
            <th>TestCase Name</th>
            <th>Project Name</th>
            <th>Last Updated By</th>
          </tr>
        </thead>
        <tbody>{this.renderTable()}</tbody>
      </table>
    );
  }
}

const mapStateToProps = (state) => {
  return { tc: Object.values(state.tc) };
};
export default connect(mapStateToProps, { getTc })(requireAuth(LoadingPage));
