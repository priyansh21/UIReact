import React from "react";
import { connect } from "react-redux";
import Headers from "./Headers";

class App extends React.Component {
  render() {
    return (

      <div className="ui-container">
        <Headers />
        {this.props.children}
      </div>

    );
  }
}
const mapStateToProps = (state) => {
  return { isSignedIn: state.auth.isSignedIn };
};
export default connect(mapStateToProps)(App);
