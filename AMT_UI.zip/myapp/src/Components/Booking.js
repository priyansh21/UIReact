// import React from "react";
// import { useSelector, useDispatch } from "react-redux";
// import { booking } from "../Actions";
// import "react-dates/initialize";
// import "bootstrap/dist/css/bootstrap.min.css";
// import {
//   DateRangePicker,
//   SingleDatePicker,
//   DayPickerRangeController,
// } from "react-dates";
// import "react-dates/lib/css/_datepicker.css";

// const Booking = () => {
//   const ui = useSelector((state) => {
//     return state.booking;
//   });
//   const dispatch = useDispatch();
//   return (
//     <div>
//       Bookings Page
//       <SingleDatePicker
//         date={this.state.date} // momentPropTypes.momentObj or null
//         onDateChange={(date) => this.setState({ date })} // PropTypes.func.isRequired
//         focused={this.state.focused} // PropTypes.bool
//         onFocusChange={({ focused }) => this.setState({ focused })} // PropTypes.func.isRequired
//         id="your_unique_id" // PropTypes.string.isRequired,
//       />
//       <div>{JSON.stringify(ui)}</div>
//       <input type="checkbox" value={ui} onChange={() => dispatch(booking())} />
//     </div>
//   );
// };

// export default Booking;

import { useSelector, useDispatch } from "react-redux";
import { booking } from "../Actions";
import "react-dates/initialize";
import "bootstrap/dist/css/bootstrap.min.css";
import TestComponent from "./TestComponent";
import {
  DateRangePicker,
  SingleDatePicker,
  DayPickerRangeController,
} from "react-dates";
import "react-dates/lib/css/_datepicker.css";
import { connect } from "react-redux";
import React, { Component } from "react";
import { map } from "lodash";

class Booking extends Component {
  state = { date: "" };
  render() {
    return (
      <div>
        <div>
          <SingleDatePicker
            date={this.state.date} // momentPropTypes.momentObj or null
            onDateChange={(date) => {
              console.log(date);
              this.setState({ date });
              this.props.booking();
            }} // PropTypes.func.isRequired
            focused={this.state.focused} // PropTypes.bool
            onFocusChange={({ focused }) => this.setState({ focused })} // PropTypes.func.isRequired
            id="your_unique_id" // PropTypes.string.isRequired,
          />
          <button onClick={() => alert(this.state.date)}>CLick</button>
        </div>
        <TestComponent />
      </div>
    );
  }
}
const mapStateToProps = (state) => {
  return { bookings: state.bookings };
};
export default connect(mapStateToProps, { booking })(Booking);
