import React from "react";
import Chart from "./Chart";
import ChartsPage from "./ChartsPage";

const Home = () => {
  return (

    <div className="grid-container panel-body">
      <Chart type="Doughnut" />
      <Chart type="Bar" />
      <Chart type="Line" />
      <Chart type="Pie" />
    </div>
  );
};

export default Home;
