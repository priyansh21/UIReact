import React from "react";
import { connect } from "react-redux";
import { signIn } from "../Actions";
import amt from "../apis/amt";
import LoginForm from "./LoginForm";

class Login extends React.Component {
  state = { response: "" };
  headers = { Authorization: "Basic " + btoa("ps00503946:Testing123") };

  onPageLoad1 = () => {
    if (!this.state.response) return <div>Loading</div>;

    return <div>{this.state.response}</div>;
  };
  onPageLoad = async () => {
    const response = await amt.get("/api/testcases", {
      headers: this.headers,
    });
    this.setState({ response: response.data[0].tcName });
  };

  onSubmit = (formValues) => {
    this.props.signIn(formValues);
  };

  render() {
    return (
      <div className="ui container">
        <LoginForm onSubmit={this.onSubmit} />
      </div>
    );
  }
}
export default connect(null, { signIn })(Login);
