import React from "react";
import ReactDOM from "react-dom";

const Modal = (props) => {
  console.log(props.content.title);
  return ReactDOM.createPortal(
    <div onClick={props.onDismiss} className="ui dimmer modals visible active">
      <div
        onClick={(e) => e.stopPropagation()}
        className="ui standers modal visible active"
      >
        <div onKeyDown={() => console.log("event")} className="header">{props.header}</div>
        <img src={props.content.src} alt={props.content.alt} title={props.content.alt} />
        {/* <div className="content" dangerouslySetInnerHTML={{ __html: props.content.src }}> */}
        {/* {props.content} */}
        {/* </div> */}
        <div className="actions">{props.actions} </div>
      </div>
    </div >,
    document.querySelector("#modal")
  );
};

export default Modal;
