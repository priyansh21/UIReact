import React from "react";


const SignOut = () => {

    return (

        <div>Sign Out</div>
    )
}

export default SignOut;