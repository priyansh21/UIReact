import React, { Component } from "react";
import { Doughnut, Bar, Line, Pie } from "react-chartjs-2";
import { connect } from "react-redux";
import Spinner from "./Loader";
import { getReport } from "../Actions";

import "../Styles/grid.css";

class Chart extends Component {
  // constructor(params) {
  //   super(params);
  //   this.props.getReport("ps00503946", "Testing123");
  // }ssss

  componentDidMount() {
    this.props.getReport("ps00503946", "Testing123");
  }

  //added this block for reload
  timoout = setInterval(function () {
    window.location.reload();
  }, 5000000);

  componentDidUpdate() {
    if (this.props.executionResult.data === undefined) return <Spinner />;
    // once the component is updated we are fetching the chart data from API
    this.chartData = {
      labels: [...Object.keys(this.props.executionResult.data.CHART)],
      datasets: [
        {
          label: "Execution",
          data: [...Object.values(this.props.executionResult.data.CHART)],
          backgroundColor: [
            "rgba(255,99,132,0.6)",
            "rgba(23,99,132,0.6)",
            "green",
            "red",
            "rgb(245 6 6 / 93%)",
          ],
        },
      ],
    };
  }

  static defaultProps = {
    type: "Bar",
  };
  render() {
    if (this.props.executionResult.data === undefined) return <Spinner />;
    console.log("render");
    switch (this.props.type) {
      case "Bar": {
        return (
          <div className="chart chartAreaColDiv">
            <Bar
              data={this.chartData}
              options={{ maintainAspectRatio: false }}
            />
          </div>
        );
      }
      case "Doughnut": {
        return (
          <div className="chart chartAreaColDiv">
            <Doughnut
              data={this.chartData}
              options={{ maintainAspectRatio: false }}
            />
          </div>
        );
      }
      case "Line": {
        return (
          <div className="chart chartAreaColDiv">
            <div className="box">
              <Line
                data={this.chartData}
                options={{ maintainAspectRatio: false }}
              />
            </div>
          </div>
        );
      }
      case "Pie": {
        return (
          <div className="chart chartAreaColDiv">
            <div className="box">
              <Pie
                data={this.chartData}
                options={{ maintainAspectRatio: false }}
              />
            </div>
          </div>
        );
      }
      default: {
        return (
          <div className="chart chartAreaColDiv">
            <Bar
              data={this.chartData}
              options={{ maintainAspectRatio: false }}
            />
          </div>
        );
      }
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    getReport: (username, password) => {
      const obj = getReport(username, password);

      dispatch(obj);
    },
  };
};
const mapStateToProps = (state, selfprops) => {
  console.log(state.report.data);
  return { executionResult: state.report };
};

export default connect(mapStateToProps, mapDispatchToProps)(Chart);
