import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import * as actions from "../Actions";
import "../Styles/Header.css";
class Header extends Component {
  onSignOutHandler = () => {
    console.log("signout called");
    this.props.signOut();
    alert("successfully signed out");
  };

  renderAuthButton() {
    if (this.props.auth === null || this.props.auth === false) {
      return (
        <React.Fragment>
          <Link to="/signin" className="item">
            Sign IN
          </Link>
        </React.Fragment>
      );
    } else if (this.props.auth) {
      // console.log("signed in with" + this.props.userid);
      return (
        <React.Fragment>
          <Link onClick={this.onSignOutHandler} to="/signout" className="item">
            Sign Out
          </Link>
        </React.Fragment>
      );
    }
  }

  render() {
    return (
      <div className="ui secondary  menu header">
        <Link to="/" className="active item ">
          Home
        </Link>
        <Link to="/signup" className="item">
          Sign Up
        </Link>

        <Link to="/AutoMaTics/index" className="item">
          AutoMaTics
        </Link>
        <Link to="/AutoMaTics/report" className="item">
          Report
        </Link>
        <div className="right menu">{this.renderAuthButton()}</div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return { auth: state.auth.isSignedIn };
};

export default connect(mapStateToProps, actions)(Header);
