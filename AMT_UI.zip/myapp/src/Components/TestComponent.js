import React from "react";
import { useSelector } from "react-redux";

const TestComponent = () => {
  const ui = useSelector((state) => {
    return state.bookings;
  });

  const slotsHelper = () => {
    console.log(ui);
    const obj = Object.values(ui);
    return obj.map((each, index) => {
      return (
        <>
          <button
            style={{ fontSize: "10px" }}
            value={each.timeSlotStart}
            key={each.timeSlotStart}
          >
            {each.timeSlotStart}
          </button>
        </>
      );
    });
  };

  console.log(ui);

  if (ui === null) {
    console.log("inside undefined ");
    return <>Loading</>;
  }
  return <>{slotsHelper()}</>;
};

export default TestComponent;

TestComponent.propTypes = {};
