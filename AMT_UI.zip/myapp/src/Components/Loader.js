import React from "react"
import { TransitionGroup } from 'react-transition-group';
import "../Styles/Transition.css"
const Spinner = () => {

  return (<div>
    {/* <TransitionGroup
      transitionName="example"
      transitionEnterTimeout={100} 
      transitionLeaveTimeout={100}> */}
    <div className='ui active dimmer' >
      <div className="ui massive text loader">Loading</div>
    </div>
    {/* </TransitionGroup> */}
  </div>

  )
}


export default Spinner;


