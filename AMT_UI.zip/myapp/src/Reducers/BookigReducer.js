import { FREE_SLOT } from "../Actions/types";

export default (state = null, action) => {
  switch (action.type) {
    case FREE_SLOT:
      return { ...state, ...action.payload.data };
    default:
      return state;
  }
};
