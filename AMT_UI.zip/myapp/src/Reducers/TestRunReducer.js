import { GET_TEST_RUN } from "../Actions/types";

export default (state = {}, action) => {
  switch (action.type) {
    case GET_TEST_RUN:
      console.log("inside reduce");
      return { ...state, ...action.payload };
    default:
      return state;
  }
};
