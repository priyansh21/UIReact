import { GET_TEST_EXECUTION } from "../Actions/types";

export default (state = {}, action) => {
  switch (action.type) {
    case GET_TEST_EXECUTION:
      console.log("inside reduce");
      return { ...state, ...action.payload };
    default:
      return state;
  }
};
