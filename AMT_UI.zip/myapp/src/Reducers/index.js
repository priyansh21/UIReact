import { combineReducers } from "redux";
import { reducer as formReducer } from "redux-form";
import AuthReducer from "./AuthReducer";
import TCReducer from "./TCReducer";
import DashboardReducers from "./DashboardReducers";
import TestRunReducer from "./TestRunReducer";
import BookigReducer from "./BookigReducer";
export default combineReducers({
  auth: AuthReducer,
  form: formReducer,
  tc: TCReducer,
  report: DashboardReducers,
  TestRunData: TestRunReducer,
  bookings: BookigReducer,
});
