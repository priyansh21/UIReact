import { GET_TC } from "../Actions/types";
import _ from "lodash";
export default (state = {}, action) => {
  switch (action.type) {
    case GET_TC:
      // console.log(..._.mapKeys(action.payload, "tcName"));
      return { ...state, ..._.mapKeys(action.payload, "tcName") };
    default:
      return state;
  }
};
