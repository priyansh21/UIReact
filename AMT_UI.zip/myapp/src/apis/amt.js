import axios from "axios";

export default axios.create({
  // baseURL: "http://192.168.0.105:3001",
  baseURL: "http://localhost:3001",
});
